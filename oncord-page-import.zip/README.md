# Strategic Self-Advocacy Lexicon v0.2.0

Oncord page-import release for the complete SSA Lexicon publication surface.

- 145 exported pages
- 142 SSA pages upgraded
- 93 concept pages
- 17 scheme pages
- Embedded JSON-LD on every SSA page
- SKOS + Schema.org + Dublin Core + PROV-O metadata
- Shared accessible CSS and persistent accessibility controls

Upload `oncord-page-import.zip` through Oncord's page import. The machine language is embedded in `website_pages.json`; the JSON-LD and CSV files are mirrors for validation and reuse, not substitutes for the page data.
